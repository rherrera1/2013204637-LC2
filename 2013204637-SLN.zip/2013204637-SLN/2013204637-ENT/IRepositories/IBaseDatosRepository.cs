﻿using _2013204637;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2013204637_ENT.IRepositories
{
    public interface IBaseDatosRepository : IRepository<BaseDatos>
    {
    }
}
